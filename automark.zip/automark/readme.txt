-Compile your program with .out extension
	e.g. gcc -o e18xxx.out e18xxx.c

-Place the binary file inside root folder (automark)
	Make sure you are having a .out file

-Open linux terminal and navigate inside root folder

-To start testing
	Run runTests.sh script (./runTests.sh)

-To view marks (negative marks)
	Run getmarks.sh script (./getmarks.sh)

-To add more test cases
	Navigate to inputs folder
	Create .inp files
	Add your arguments and save (No need to add program name. Observe given 2 inputs and do.)

Covering all possible error scenarios is your work!
Do not ask me!

GOOD LUCK! Get 10/10 :D